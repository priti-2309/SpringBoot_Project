package com.example.BMS.service;

import com.example.BMS.entity.Customer;
import com.example.BMS.exception.ResourceNotFoundException;
import com.example.BMS.repo.CustomerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class customerService {

    @Autowired
    private CustomerRepo customerRepo;

    //For creating customer
    public Customer saveCustomer(Customer customer) {
        return customerRepo.save(customer);
    }
    
    //To update customer by ID
    public Customer updateCustomer(Long customerId, Customer customer) {
        // Check if the customer exists
        Optional<Customer> existingCustomerOptional = customerRepo.findById(customerId);

        if (existingCustomerOptional.isPresent()) {
            // Get the existing customer
            Customer existingCustomer = existingCustomerOptional.get();

            // Update the existing customer fields with new data
            existingCustomer.setName(customer.getName());
            existingCustomer.setEmail(customer.getEmail());
            existingCustomer.setPhone(customer.getPhone());
      
            // Save the updated customer back to the repository
            return customerRepo.save(existingCustomer);
        } else {
            // Return null if the customer is not found
            return null;
        }
    }

    // Get all customers
    public List<Customer> getAllCustomers() {
        return customerRepo.findAll();
    }

    // Get customer by ID
    public Customer getCustomerById(Long customerId) {
        Optional<Customer> customer = customerRepo.findById(customerId);
        if (customer.isPresent()) {
            return customer.get();
        } else {
            throw new ResourceNotFoundException("Customer not found with id: " + customerId);
        }
    }

    // Delete customer by ID
    public void deleteCustomer(Long customerId) {
        Optional<Customer> customer = customerRepo.findById(customerId);
        if (customer.isPresent()) {
            customerRepo.deleteById(customerId);
        } else {
            throw new ResourceNotFoundException("Customer not found with id: " + customerId);
        }
    }
}
