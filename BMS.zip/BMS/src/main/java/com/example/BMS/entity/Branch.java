package com.example.BMS.entity;

import javax.validation.constraints.NotNull;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Table(name="branch")
@Getter
@Setter
public class Branch {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long branch_id;
	    
	    @Column(length=20,nullable=false)
	    @NotNull(message="Enter branch name")
	    private String name;
	    
	    @Column(length=20,nullable=false)
	    @NotNull(message="Enter branch address")
	    private String address;

}
