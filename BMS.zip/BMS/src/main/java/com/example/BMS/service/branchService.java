package com.example.BMS.service;

import com.example.BMS.entity.Branch;
import com.example.BMS.exception.ResourceNotFoundException;
import com.example.BMS.repo.BranchRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class branchService {

    @Autowired
    private BranchRepo branchRepo;

    // Adding Branch details
    public Branch saveBranch(Branch branch) {
        return branchRepo.save(branch);
    }
    
  //To update branch details
    public Branch updateBranch(Long branch_id, Branch branch) {
        Optional<Branch> existingBranchOptional = branchRepo.findById(branch_id);

        if (existingBranchOptional.isPresent()) {
            Branch existingBranch = existingBranchOptional.get();

            existingBranch.setName(branch.getName());
            existingBranch.setAddress(branch.getAddress());
      
            return branchRepo.save(existingBranch);
        } else {
            return null;
        }
    }

    // Get all branches
    public List<Branch> getAllBranches() {
        return branchRepo.findAll();
    }

    // Get branch detail by Branch ID
    public Branch getBranchById(Long branch_id) {
        Optional<Branch> branch = branchRepo.findById(branch_id);
        if (branch.isPresent()) {
            return branch.get();
        } else {
            throw new ResourceNotFoundException("Branch not found with id: " + branch_id);
        }
    }

    // Delete branch by ID
    public void deleteBranch(Long branch_id) {
        Optional<Branch> branch = branchRepo.findById(branch_id);
        if (branch.isPresent()) {
            branchRepo.deleteById(branch_id);
        } else {
            throw new ResourceNotFoundException("Branch not found with id: " + branch_id);
        }
    }
}
