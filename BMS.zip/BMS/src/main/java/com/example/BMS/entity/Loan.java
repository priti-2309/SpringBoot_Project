package com.example.BMS.entity;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Table(name="loan")
@Getter
@Setter
public class Loan {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long loan_id;
    
    @Column(length=10,nullable=false)
    @NotNull(message="Enter the loan amount")
    @Positive(message="Amount must be greater than 0")
    private Double amount;
}
