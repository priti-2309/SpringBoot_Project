package com.example.BMS.entity;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Table(name="employee")
@Getter
@Setter
public class Employee {
	@Id
    private Long emp_id;
    
    @Column(length=20,nullable=false)
    @NotNull(message="Enter the employee's name")
    @Size(min=2,max=20)
    private String name;
    
    @Column(length=20,nullable=false)
    @NotNull(message="Enter the employee's position")
    private String position;
    
    @Column(length=6,nullable=false)
    @NotNull(message="Enter the employee's salary")
    private Double salary;
}
